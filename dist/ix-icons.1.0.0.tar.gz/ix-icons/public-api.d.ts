export * from './lib/ix-icons.module';

export declare class IxThemeButtonModule {
}

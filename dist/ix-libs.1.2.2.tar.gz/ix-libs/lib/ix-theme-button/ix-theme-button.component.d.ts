import { NgZone, OnInit } from '@angular/core';
import { IxDarkService } from '../ix-dark/ix-dark.service';
export declare class ThemeButtonComponent implements OnInit {
    private ngZone;
    private darkService;
    theme: string;
    constructor(ngZone: NgZone, darkService: IxDarkService);
    toggleDarkMode(): void;
    private _subToTheme;
    ngOnInit(): void;
}

/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { LocalStorageService as ɵa } from './lib/shared/storage.service';

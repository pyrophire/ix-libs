export * from './lib/ix-icons/ix-icons.module';
export * from './lib/ix-scroll/ix-scroll.module';
export * from './lib/ix-scroll/ix-scroll.service';
export * from './lib/ix-scroll/ix-scroll.component';

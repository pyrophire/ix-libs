import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
export declare class IxIconsModule {
    constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer);
}

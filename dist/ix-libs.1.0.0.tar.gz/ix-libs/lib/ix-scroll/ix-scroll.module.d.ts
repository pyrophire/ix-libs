export declare class IxScrollModule {
}
